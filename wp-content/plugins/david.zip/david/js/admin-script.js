
;(function($){
    $(document).ready(function() {
        $('body').on('click','.fakeButton',function(){
            $(this).hide();
            $(this).parent().find($('.textFakeButton')).show();
        })
        $('body').on('click','.btnAnnuler',function(){
            $(this).parent().parent().find($('.fakeButton')).show();
            $(this).parent().parent().find($('.textFakeButton')).hide();
        })
        
        $('.texte_scan_en_cours').fadeIn().delay(5000).fadeOut();
    });

})(jQuery);
